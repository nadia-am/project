<?php
return[
    'types' => [
        'sms'=>'SMS',
        'off'=>'DISABLE'
    ]
];
