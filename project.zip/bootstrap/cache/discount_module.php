<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Discount\\Providers\\DiscountServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Discount\\Providers\\DiscountServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);